## Non-modular samples for IntelliJ

JavaFX 13 samples to run from IntelliJ with different options and build tools

Version IntelliJ IDEA 2019.1

Download [JDK 11 or later](http://jdk.java.net/) for your operating system.
Make sure `JAVA_HOME` is properly set to the JDK installation directory. 

### Gradle

Clone the sample, open it with IntelliJ and import the Gradle changes. Build or run
from the Gradle window.